using System.Globalization;
class Fisica{
    public float massa;
    private float gravidade = 9.8f;
    public float velocidade;
    public float k;
    public float x;
    public float altura;
    private float tempo;
    private float distancia;
    
    public Fisica( float massa, float gravidade, float velocidade,float k, float x, float altura, float tempo, float distancia){
        this.massa = massa;
        this.gravidade = gravidade;
        this.velocidade = velocidade;
        this.k = k;
        this.x = x;
        this.altura = altura;
        this.tempo = tempo;
        this.distancia = distancia;
    }
    
    public float SetMassa(float massa){
        return this.massa = massa;
    }
    public float GetMassa(){
        return massa ;
    }
    public float SetGravidade(float gravidade){
        return this.gravidade = gravidade;
    }
    public float GetGravidade(){
        return gravidade;
    }
    public float SetVelocidade(float velocidade){
        return this.velocidade = velocidade;
    }
    public float GetVelocidade(){
        return velocidade ;
    }
    public float SetK(float k){
        return this.k = k;
    }
    public float SetX(float x){
        return this.x = x;
    }
    public float SetAltura(){
        return altura ;
    }
    public float SetTempo(){
        return this.tempo;
    }
    public float GetTempo(){
        return tempo;
    }
    public float SetDistancia(){
        return this.distancia;
    }
    public float GetDistancia(){
        return distancia;
    }
    public float Em1(){ 
        return (massa * gravidade * altura + ((massa * velocidade * velocidade) / 2));
    }
    public float Em2(){
        return (massa * gravidade * altura) + ((massa * (velocidade * velocidade) / 2) + (k *(x *  x)/2)); 
    }
    public float Vm(){
        return (distancia / tempo);
        
    }
}