class Calculadora{
    public float tempo;
    public float distancia;
    private float velocidadeMedia;

    public Calculadora(float tempo, float distancia, float VelocidadeMedia){
        tempo = tempo;
        distancia = distancia;
        VelocidadeMedia = VelocidadeMedia;
    }
    public float GetVelocidadeMedia(){
        return velocidadeMedia;
    }
    public float SetVelocidadeMedia(float Vm){
        return velocidadeMedia = Vm;
        
    }
    public float CalcularVelocidadeMedia(){
        return velocidadeMedia = distancia / tempo;
        
    }



}