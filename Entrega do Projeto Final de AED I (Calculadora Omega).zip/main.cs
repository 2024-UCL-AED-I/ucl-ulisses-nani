
using System.Text;
using System;
using System.IO;

class Program
{
    static void Main(string[] args)
    {
        Matematica mat1 = new Matematica();
        Fisica fisi1 = new Fisica();
        
        string path = "CalculadoraOmega2.txt"; // Caminho do arquivo
        StreamWriter sw = null; // Declaração do StreamWriter fora do loop

        try
        {
            // Abre o arquivo para escrita (modo Append para adicionar ao final)
            sw = new StreamWriter(path, true);
            
            while (true)
            {
                Console.WriteLine("Escolha uma opção:");
                Console.WriteLine("1 - Calcular Área do Retângulo");
                Console.WriteLine("2 - Calcular Área do Triângulo");
                Console.WriteLine("3 - Calcular Área da Circunferência");
                Console.WriteLine("4 - Exibir Tabuada");
                Console.WriteLine("5 - Calcular Energia Mecânica 1");
                Console.WriteLine("6 - Calcular Energia Mecânica 2");
                Console.WriteLine("7 - Calcular Velocidade Média");
                Console.WriteLine("8 - Sair");

                int opcao;
                if (!int.TryParse(Console.ReadLine(), out opcao))
                {
                    Console.WriteLine("Opção inválida! Digite um número de 1 a 8.");
                    continue;
                }

                switch (opcao)
                {
                    case 1:
                        Console.Write("Digite a altura do retângulo: ");
                        float alturaRetangulo = float.Parse(Console.ReadLine());
                        mat1.SetAltura(alturaRetangulo);
                        Console.Write("Digite a base do retângulo: ");
                        float baseRetangulo = float.Parse(Console.ReadLine());
                        mat1.SetBas(baseRetangulo);

                        Console.WriteLine($"Área do retângulo: {mat1.Retangulo()}");
                        sw.WriteLine($"Área do retângulo: {mat1.Retangulo()}");
                        break;

                    case 2:
                        Console.Write("Digite a altura do triângulo: ");
                        float alturaTriangulo = float.Parse(Console.ReadLine());
                        mat1.SetAltura(alturaTriangulo);

                        Console.Write("Digite a base do triângulo: ");
                        float baseTriangulo = float.Parse(Console.ReadLine());
                        mat1.SetBas(baseTriangulo);

                        Console.WriteLine($"Área do triângulo: {mat1.Triangulo()}");
                        sw.WriteLine($"Área do triângulo: {mat1.Triangulo()}");
                        break;

                    case 3:
                        Console.Write("Digite o raio da circunferência: ");
                        float raioCircunferencia = float.Parse(Console.ReadLine());
                        mat1.SetRaio(raioCircunferencia);

                        Console.WriteLine($"Área da circunferência: {mat1.Circulo()}");
                        sw.WriteLine($"Área da circunferência: {mat1.Circulo()}");
                        break;

                    case 4:
                        Console.Write("Digite um número para a tabuada: ");
                        int numeroTabuada = int.Parse(Console.ReadLine());
                        mat1.SetN1(numeroTabuada);
                        mat1.SetRes(numeroTabuada);
                        for(int i = 0; i <= 10; i++) {
                            mat1.res = numeroTabuada * i;
                        }

                        mat1.Tabuada();
                        sw.WriteLine($"Tabuada do {mat1.res}:");
                        break;

                    case 5:
                        Console.Write("Digite a massa: ");
                        float massaEm1 = float.Parse(Console.ReadLine());
                        fisi1.SetMassa(massaEm1);

                        Console.Write("Digite a altura: ");
                        float alturaEm1 = float.Parse(Console.ReadLine());
                        mat1.SetAltura(alturaEm1);

                        Console.Write("Digite a velocidade: ");
                        float velocidadeEm1 = float.Parse(Console.ReadLine());
                        fisi1.SetVelocidade(velocidadeEm1);

                        Console.WriteLine($"Energia Mecânica 1: {fisi1.Em1()}");
                        sw.WriteLine($"Energia Mecânica 1: {fisi1.Em1()} N/ms²");
                        break;

                    case 6:
                        Console.Write("Digite a massa: ");
                        float massaEm2 = float.Parse(Console.ReadLine());
                        fisi1.SetMassa(massaEm2);

                        Console.Write("Digite a altura: ");
                        float alturaEm2 = float.Parse(Console.ReadLine());
                        mat1.SetAltura(alturaEm2);

                        Console.Write("Digite a velocidade: ");
                        float velocidadeEm2 = float.Parse(Console.ReadLine());
                        fisi1.SetVelocidade(velocidadeEm2);

                        Console.Write("Digite a constante elástica (k): ");
                        float kEm2 = float.Parse(Console.ReadLine());
                        fisi1.SetK(kEm2);

                        Console.Write("Digite o deslocamento (x): ");
                        float xEm2 = float.Parse(Console.ReadLine());
                        fisi1.SetX(xEm2);

                        Console.WriteLine($"Energia Mecânica 2: {fisi1.Em2()}");
                        sw.WriteLine($"Energia Mecânica 2: {fisi1.Em2()} N/ms²");
                        break;

                    case 7:
                        Console.Write("Digite a distância percorrida para calcular a Vm: ");
                        float distanciaVm = float.Parse(Console.ReadLine());
                        fisi1.SetDistancia(distanciaVm);

                        Console.Write("Digite o tempo gasto: ");
                        float tempoVm = float.Parse(Console.ReadLine());
                        fisi1.SetTempo(tempoVm);

                        Console.WriteLine($"Velocidade Média: {fisi1.Vm()}");
                        sw.WriteLine($"Velocidade Média: {fisi1.Vm()} m/s²");
                        break;

                    case 8:
                        Console.WriteLine("Encerrando o programa...");
                        Environment.Exit(0);
                        break;

                    default:
                        Console.WriteLine("Opção inválida! Digite um número de 1 a 8.");
                        break;
                }

                Console.WriteLine(); // Linha em branco para separar iterações
            }
        }
        catch (IOException e)
        {
            Console.WriteLine($"Erro ao tentar acessar o arquivo: {e.Message}");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Ocorreu um erro: {ex.Message}");
        }
        finally
        {
            if (sw != null)
            {
                sw.Close(); // Fecha o StreamWriter
            }
        }
    }
    
}