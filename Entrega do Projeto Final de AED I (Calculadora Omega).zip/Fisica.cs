
class Fisica{
    public float massa;
    private float gravidade = 9.8f;
    public float velocidade;
    public float k;
    public float x;
    public float altura;
    private float tempo;
    private float distancia;
    
    public Fisica(){
        this.massa = 0;
        this.gravidade = 0;
        this.velocidade = 0;
        this.k = 0;
        this.x = 0;
        this.altura = 0;
        this.tempo = 0;
        this.distancia = 0;
    }
    
    public void SetMassa(float mass){
        this.massa = mass;
    }
    public float GetMassa(){
        return massa ;
    }
    public void SetGravidade(float gravidade){
        this.gravidade = gravidade;
    }
    public float GetGravidade(){
        return gravidade;
    }
    public void SetVelocidade(float v){
        this.velocidade = v;
    }
    public float GetVelocidade(){
        return velocidade ;
    }
    public void SetK(float k){
        this.k = k;
    }
    public void SetX(float x){
        this.x = x;
    }
    public void SetAltura(float alt){
        this.altura = alt ;
    }
    public void SetTempo(float temp){
        this.tempo = temp;
    }
    public float GetTempo(){
        return tempo;
    }
    public void SetDistancia(float dist){
         this.distancia = dist;
    }
    public float GetDistancia(){
        return distancia;
    }
    public float Em1(){ 
        return (massa * gravidade * altura + ((massa * velocidade * velocidade) / 2));
    }
    public float Em2(){
        Matematica  mat = new Matematica();
        mat.SetAltura(altura);
        return (massa * gravidade * altura) + ((massa * (velocidade * velocidade) / 2) + (k *(x *  x)/2)); 
    }
    public float Vm(){
        return (distancia / tempo);
        
    }
}