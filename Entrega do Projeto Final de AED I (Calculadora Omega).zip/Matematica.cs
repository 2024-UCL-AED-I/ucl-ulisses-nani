
class Matematica{
    private float altura;
    private float raio;
    private float pi = 3.14f;
    private float bas;
    private int n1;
    private int n2 ;
    public int res;

    public  Matematica( ){
        this.altura = 0;
        this.bas = 0;
        this.n1 = 0;
        this.n2 = 0;
        this.raio = 0;
        this.pi = 3.14f;
        this.res = 0 ;
    }
    public void SetAltura(float altura){
        this.altura = altura;

    }
    public float GetAltura(){
        return altura ;
        
    }
    public void SetBas(float bas){
        this.bas = bas;
    }
    public float GetBas(){
        return bas ;
    }
    public void SetN1(int n1){
        this.n1 = n1;
    }
    public void SetRaio(float r){
        this.raio = r;
    }
    public void SetRes(int res){
        this.res = res;
    }
    public void SetPi(float pi){
        this.pi = 3.14f;
    }
    public float Quadrado(){
        return bas * altura;

    }
    public float Retangulo(){
        return bas * altura;
    }
    public float Triangulo(){
        return (bas * altura) / 2;

    }
    public float Circulo(){
        return pi * (raio * raio);
    }
    public int Tabuada(){
        Fisica fisi = new Fisica();
        fisi.SetAltura(altura);
        for(n2 = 0; n2 <= 10; n2++){
            res = n1 * n2;
        }
        return res ;
    }

        
}